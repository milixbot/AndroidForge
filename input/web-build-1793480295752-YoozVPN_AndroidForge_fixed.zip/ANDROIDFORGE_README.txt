YoozVPN / v2rayNG Android source archive for AndroidForge

This archive has been repacked so the Gradle project root is the ZIP root.
The root contains settings.gradle.kts, build.gradle.kts, gradlew, gradle/ and app/.

IMPORTANT: The original upstream ZIP omitted the contents of these Git submodules:
- AndroidLibXrayLite
- hev-socks5-tunnel
Those dependencies are not included in this archive. The original repository uses
its GitHub Actions workflow to fetch/build them. This repack fixes the reported
“does not contain a Gradle build” directory error, but does not claim that all
upstream native/AAR dependencies are bundled or that a build will complete.

Upstream project: https://github.com/2dust/v2rayNG
